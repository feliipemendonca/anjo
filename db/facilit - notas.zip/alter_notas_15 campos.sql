ALTER TABLE tb_notas
ADD nota5 FLOAT(3, 2),ADD envio_nota5 DATE,
ADD nota6 FLOAT(3, 2),ADD envio_nota6 DATE,
ADD nota7 FLOAT(3, 2),ADD envio_nota7 DATE,
ADD nota8 FLOAT(3, 2),ADD envio_nota8 DATE,
ADD nota9 FLOAT(3, 2),ADD envio_nota9 DATE,
ADD nota10 FLOAT(3, 2),ADD envio_nota10 DATE,
ADD nota11 FLOAT(3, 2),ADD envio_nota11 DATE,
ADD nota12 FLOAT(3, 2),ADD envio_nota12 DATE,
ADD nota13 FLOAT(3, 2),ADD envio_nota13 DATE,
ADD nota14 FLOAT(3, 2),ADD envio_nota14 DATE,
ADD nota15 FLOAT(3, 2),ADD envio_nota15 DATE;